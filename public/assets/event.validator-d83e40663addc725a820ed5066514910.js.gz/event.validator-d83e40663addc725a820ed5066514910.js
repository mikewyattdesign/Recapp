(function() {
  this.EVENTVALIDATOR = (function() {
    var init;
    return init = function() {};
  })();

}).call(this);
