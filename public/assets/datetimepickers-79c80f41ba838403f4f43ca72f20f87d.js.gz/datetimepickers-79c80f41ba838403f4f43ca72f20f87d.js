(function() {
  $(document).ready(function() {
    $('.datepicker').datepicker();
    $('.timepicker').timepicker();
  });

}).call(this);
