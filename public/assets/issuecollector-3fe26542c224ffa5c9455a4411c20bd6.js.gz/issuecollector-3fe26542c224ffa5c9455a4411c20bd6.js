// Requires jQuery!
$(document).on('page:load ready', function(){
	jQuery.ajax({
	    url: "https://group360.atlassian.net/s/d41d8cd98f00b204e9800998ecf8427e/en_US-h3yd8m-1988229788/6252/31/1.4.7/_/download/batch/com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector-embededjs/com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector-embededjs.js?collectorId=920c8a8a",
	    type: "get",
	    cache: true,
	    dataType: "script"
	});
});
